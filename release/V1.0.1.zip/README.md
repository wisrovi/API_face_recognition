# API_face_recognition
API reconocimiento facial con JWT

Un completo sistema de reconocimiento facial en modo API con servicio de api-rest para su facil uso en los diferentes proyectos.

Tiene documentacion en /docs usando swagger

Tiene control de licencias donde se visualiza el consumo de bytes, restriccion de rostros vectorizados (un rostro-vectorizado es un rostro que se puede reconocer), fecha vencimiento de licencia, todos los parametros son configurables.

Por ahora no usa comunicacion con una base de datos, esta es la siguiente version de mejora para enlazarlo con un motor de base de datos, por ejemplo mysql.


